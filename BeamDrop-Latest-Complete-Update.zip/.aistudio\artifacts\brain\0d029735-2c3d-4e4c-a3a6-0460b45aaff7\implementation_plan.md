# BeamDrop - Universal Fluid Tap-to-Share for Android

BeamDrop brings the seamless, magical tap-to-share experience seen in Apple's ecosystem (NameDrop and AirDrop handoff) to every Android smartphone. By uniting NFC tap sensing, proximity/bump gesture detection, and a high-speed local peer-to-peer Wi-Fi transfer engine with fluid Canvas aura bloom and ripple animations, users can touch phones together to beam photos, 4K videos, documents, and folders with near-zero latency and high visual fidelity.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The following product and design choices were confirmed during Phase 1 clarification:

- **Confirmed Gesture & Trigger Mechanism**: Dual NFC tap and proximity sensor gesture (touching the top of two phones together triggers the connection and particle bloom handoff, with a manual radar/tap simulator fallback for devices without NFC or single-device testing).
- **Confirmed Visual Aesthetic**: Glowing fluid aura and edge bloom ripple—featuring dynamic liquid gradients, edge-diffused glow expanding from the phone's top bezel, particle vortex trails, and tactile haptic ripples.
- **Confirmed App Name**: **BeamDrop**.

---

### 1. Overview & Core Concept

- **What It Does**: BeamDrop allows any Android user to select files (photos, videos, audio, documents, apps), bring their phone near or touch tops with another Android device, and watch a glowing aura wave ripple across the screen as the file glides effortlessly from one device to the other.
- **Target Audience / Persona**: Everyday smartphone users, content creators, photographers, and professionals tired of cumbersome Bluetooth pairings, cloud upload limits, compression artifacts, or proprietary single-brand walled gardens (like Quick Share locked within certain vendor accounts or AirDrop limited to iOS).
- **Key Value**:
  1. Universal compatibility across all Android OEMs (Samsung, Google Pixel, Xiaomi, OnePlus, Motorola, etc.).
  2. Zero cloud dependency or mobile data usage (100% direct device-to-device local Wi-Fi transfer exceeding 50 MB/s).
  3. Mesmerizing fluid aesthetics with organic physics-based animations that match or exceed the Apple ecosystem's fluidity.

---

### 2. User Experience & Visual Design

#### Key User Flows
1. **Browse & Select**:
   - The user opens BeamDrop to an organized media tray categorized by Photos, Videos, Documents, Audio, and Apps.
   - Live file previews with multi-select chips, total payload size counter, and instant photo/video thumbnail cards.
2. **Touch-to-Beam (Tap Handoff)**:
   - When files are staged, the app enters **"Beam Ready"** mode with an organic pulsing top-edge light halo.
   - Bringing phones top-to-top activates the **Proximity Sensor + NFC payload exchange**.
   - A dramatic liquid aura bloom erupts from the top bezel, sending rhythmic light ripples downwards across the screen accompanied by progressive haptic pulses.
3. **High-Speed Glide & Transfer**:
   - The staged file card smoothly detaches with spring physics, floating upward as if being absorbed into the other device.
   - Real-time transfer HUD displays instantaneous transfer speed (e.g. `48.2 MB/s`), dynamic ETA, bytes transferred, and glowing wave progress ring.
4. **Instant Receive & Open**:
   - The receiver phone displays an incoming beam banner with sender identity and file thumbnail.
   - File downloads directly to device storage with instant "Open", "Share", or "Show in Folder" actions.
5. **Radar & Quick Nearby Discovery**:
   - If not physically touching, a pulsing radar scanner displays nearby active BeamDrop peers in the room with one-tap transfer.
6. **Transfer History & Storage Vault**:
   - Detailed ledger of sent and received transfers with direct file opening, re-sharing, and storage management.

#### Visual Identity & Theme
- **Theme**: Luxury Deep Cyber-Dark (`#0B0E14` base background) with vibrant Electric Cyan (`#00F5D4`), Ultra Violet (`#7B2CBF`), and Solar Amber (`#FFB703`) aura glows.
- **Atmosphere**: Radial Canvas mesh glows and translucent frosted glass cards (`surfaceContainerLow` with subtle borders and tonal elevation).
- **Typography**: Clean, geometric modern typography with prominent numeric readouts for transfer rates and file sizes.
- **Motion & Haptics**:
  - Spring-driven sheet expansions (`spring(dampingRatio = 0.75f, stiffness = 400f)`).
  - Canvas-rendered multi-ring liquid ripple shader simulating light refraction along screen borders.
  - Tactile feedback corresponding to proximity detection, connection lock, and packet completion.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Dual-Layer Connection Architecture (NFC + Proximity + Local Wi-Fi)**
  - *Chosen Approach*: NFC NDEF message push combined with Android Proximity & Accelerometer bump detection for the "touch" trigger, paired with direct high-speed local TCP socket / Wi-Fi peer transfer for actual payload delivery.
  - *Why*: NFC alone cannot transfer gigabytes of video (bandwidth is ~424 kbps). Using NFC/Proximity strictly for instantaneous handshake (<150ms) and Wi-Fi/Hotspot socket for payload yields the exact Apple NameDrop feel with blazing 50+ MB/s file transfers.
  - *Alternatives Considered*: Pure Bluetooth Low Energy (too slow for 4K video) or Cloud Relay (requires internet, data usage, and accounts).
- **Decision 2: Interactive Touch-to-Beam Simulator & Live Testing**
  - *Chosen Approach*: Provide a built-in "Simulate Top Touch / Test Transfer" mode alongside physical hardware sensor listeners.
  - *Why*: Allows testing and demonstrating the full two-device handoff, fluid animations, and receiving experience directly inside the browser streaming emulator without needing two physical phones touching in real life.
- **Decision 3: Local Persistence via Room**
  - *Chosen Approach*: On-device Room database for transfer history, recent peers, and received file index.
  - *Why*: Respects absolute privacy (zero telemetry, zero server-side storage) while giving users complete tracking of their transferred assets.

---

### 4. Technical Architecture & Data Strategy

#### Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           BeamDrop UI Layer                             │
│  ┌─────────────────────────┐   ┌─────────────────────────────────────┐  │
│  │   Media / File Picker   │   │     Fluid Aurora Canvas Ripple      │  │
│  │ (Photos/Videos/Docs/Apps)│   │  (Liquid Top-Edge Bloom & Physics)  │  │
│  └────────────┬────────────┘   └──────────────────┬──────────────────┘  │
│               │                                   │                     │
│  ┌────────────▼───────────────────────────────────▼──────────────────┐  │
│  │             BeamDropViewModel (StateFlow & Event Bus)             │  │
│  └──────┬─────────────────┬───────────────────┬─────────────────┬────┘  │
└─────────┼─────────────────┼───────────────────┼─────────────────┼───────┘
          │                 │                   │                 │
┌─────────▼────────┐ ┌──────▼─────────┐ ┌───────▼────────┐ ┌──────▼───────┐
│   Touch & Sensor │ │  NFC & Nearby  │ │  Peer Socket   │ │     Room     │
│      Manager     │ │   Discovery    │ │Transfer Engine │ │   Database   │
│ (Proximity/Bump) │ │ (NDEF / Radar) │ │ (Chunk Stream) │ │ (History/Log)│
└──────────────────┘ └────────────────┘ └────────────────┘ └──────────────┘
```

#### State & Interaction Lifecycle

```
[Idle / Files Selected]
       │
       ▼  (Bring device close or click "Simulate Top Touch")
[Proximity / NFC Triggered] ──► [Haptic Feedback + Liquid Light Bloom Expands]
       │
       ▼  (Handshake exchanged in <200ms)
[Peer Connected] ────────────► [File Card Glides Forward]
       │
       ▼  (Chunked binary stream via local high-speed channel)
[Streaming Transfer] ────────► [Real-time Speedometer & Progress Wave]
       │
       ▼  (Payload verified & saved)
[Transfer Complete] ─────────► [Success Pulse + Open File / Notification]
```

#### Core Components & Capabilities
1. **Sensor & Touch Engine**:
   - `TouchGestureManager`: Listens to `Sensor.TYPE_PROXIMITY` and `Sensor.TYPE_ACCELEROMETER` for deliberate top-bezel proximity and subtle physical tap velocity.
   - `NfcBeamManager`: Configures Android NFC Adapter for reading and pushing beam pairing payloads.
2. **Transfer Engine**:
   - `LocalTransferEngine`: High-speed local peer socket client/server streaming binary chunks with speed calculation, pause/resume, and SHA-256 verification.
3. **Fluid UI & Animation Suite**:
   - `AuroraBloomCanvas`: Custom Jetpack Compose Canvas computing radial gradients, sine-wave oscillation, edge luminance, and particle fountain physics.
   - `TransferHudSheet`: Floating dynamic island / bottom sheet displaying live transfer telemetry.
   - `MediaPickerTray`: Fast categorized grid for images, 4K videos, documents, and installed apps.
4. **History & Persistence**:
   - `TransferDatabase` (Room): Entity records with timestamps, sender/receiver, file size, MIME type, local file path, and transfer speed.
